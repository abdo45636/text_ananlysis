
import socket
import time

server = socket.socket()
server.bind(('', 3000))

print ('Server ready at 127.0.0.1')
server.listen(1)
client, address = server.accept()
print('Got connection from', address)

while True:
    text = ""
    text.append(client.recv(1024))
