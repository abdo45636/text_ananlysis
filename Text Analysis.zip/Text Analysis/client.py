

import socket
from pip._vendor.distlib.compat import raw_input
from collections import Counter

client = socket.socket()
ipaddr = raw_input('Connect to IP: ')
client.connect((ipaddr, 3000))
print('Connected to server')

while True:
    text = ""
    text = raw_input('Enter your phrase: ')
    text = text.lower()
    print('convert the text to the lower:',text)

    text2 = text.upper()
    print('convert the text to the lower:', text2)

    text3 = len(text)
    print('Length of text is ', text3)

    text4 = text.isnumeric()
    print('the text find inside number is', text4)

    text5 = text.swapcase()
    print('convert the lower text to the upper and versa:', text5)

    text6 = text.islower()
    print('The text contains words is lowercase:', text6)

    text7 = text.isupper()
    print('The text contains words is UpperCase:', text7)

    def count_words(text):  # counts word frequency
        skips = [".", ", ", ":", ";", "'", '"']
        for ch in skips:
            text = text.replace(ch, "")
        word_counts = {}
        for word in text.split(" "):
            if word in word_counts:
                word_counts[word] += 1
            else:
                word_counts[word] = 1
        return word_counts

        # >>>count_words(text)  You can check the function


    def count_words_fast(text):  # counts word frequency using Counter from collections
        text = text.lower()
        skips = [".", ", ", ":", ";", "'", '"']
        for ch in skips:
            text = text.replace(ch, "")
        word_counts = Counter(text.split(" "))
        return word_counts

        # >>>count_words_fast(text) You can check the function


    def word_stats(word_counts):  # word_counts = count_words_fast(text)
        num_unique = len(word_counts)
        counts = word_counts.values()
        return (num_unique, counts)


    word_counts = count_words_fast(text)
    (num_unique, counts) = word_stats(word_counts)
    print('appear the unique words :',num_unique)
    print('the text continue to the pharse is number of :',sum(counts))
    break